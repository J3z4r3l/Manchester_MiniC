#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2

def image_callback(msg):
    bridge = CvBridge()
    try:
        # Convert the ROS Image message to OpenCV2
        cv_image = bridge.imgmsg_to_cv2(msg, "bgr8")
    except CvBridgeError as e:
        rospy.logerr("CvBridge Error: {0}".format(e))

    # Display the image
    cv2.imshow("Aruco Image Subscriber", cv_image)
    cv2.waitKey(3)

def main():
    rospy.init_node('aruco_image_subscriber', anonymous=True)
    rospy.Subscriber('/puzzlebot_1/camera/image_raw', Image, image_callback)
    rospy.spin()

    # When done, close the OpenCV window
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
