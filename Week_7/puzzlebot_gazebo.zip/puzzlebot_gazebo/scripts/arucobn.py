#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image, JointState
from geometry_msgs.msg import PoseStamped, Twist, Quaternion
from std_msgs.msg import Float32
from tf.transformations import quaternion_from_euler

class ArucoDetector:
    def __init__(self):
        self.bridge = CvBridge()
        self.parametros = cv2.aruco.DetectorParameters_create()
        self.diccionario = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)

        self.image_sub = rospy.Subscriber('puzzlebot_1/camera/image_raw', Image, self.image_callback)
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

        self.velocity_msg = Twist()
        self.angular_p = rospy.get_param("aruco_navigation/angular_p", 0.1)
        self.radius_threshold = rospy.get_param("aruco_navigation/radius_threshold", 50)
        self.theta_precision = rospy.get_param("aruco_navigation/theta_precision", 10)
        self.linear_p = rospy.get_param("aruco_navigation/linear_p", 0.1)

        rospy.init_node('aruco_detector', anonymous=True)
        rospy.spin()

    def image_callback(self, data):
        try:
            frame = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {0}".format(e))
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        esquinas, ids, _ = cv2.aruco.detectMarkers(gray, self.diccionario, parameters=self.parametros)

        if np.all(ids != None):
            frame = cv2.aruco.drawDetectedMarkers(frame, esquinas)
            rospy.loginfo("Aruco a la vista")
            for i in range(len(ids)):
                aruco_id = ids[i][0]
                rospy.loginfo(f"ID del Aruco detectado: {aruco_id}")
                self.control_robot(aruco_id, esquinas[i])
        else:
            rospy.loginfo("Buscando Aruco")
            self.move(0, 0.4)

        cv2.imshow('Frame', frame)
        cv2.waitKey(1)

    def control_robot(self, markerID, esquina):
        center = np.mean(esquina[0], axis=0)
        frame_center = 320  # Asumiendo que el ancho de la imagen es 640
        theta_error = frame_center - center[0]

        rospy.loginfo(f"Center: {center}, Frame Center: {frame_center}, Theta Error: {theta_error}")

        if markerID == 0:
            self.move(0.2, self.angular_p * theta_error)
        elif markerID == 1:
            self.move(0.2, -self.angular_p * theta_error)
        elif markerID == 2:
            self.move(0, 0)  # Detiene el robot
            rospy.signal_shutdown("Aruco ID 2 detectado, deteniendo el robot")

    def move(self, linear, angular):
        self.velocity_msg.linear.x = linear
        self.velocity_msg.angular.z = angular
        rospy.loginfo("linear velocity " + str(linear))
        rospy.loginfo("angular velocity " + str(angular))
        self.cmd_vel_pub.publish(self.velocity_msg)

class Simulation:
    def __init__(self):
        # Initialize
        rospy.init_node("puzz_sim")
        self.loop_rate = rospy.Rate(rospy.get_param("~node_rate", 100))
        # Parameters
        self.first = True
        self.radius = 0.05
        self.wheelbase = 0.19
        self.v_ = 0.0
        self.w_ = 0.0
        self.x_dot = 0.0
        self.y_dot = 0.0
        self.theta_dot = 0.0
        # Publishers and Subscribers
        self.pub_pose = rospy.Publisher('/pose', PoseStamped, queue_size=10)
        rospy.Subscriber('/cmd_vel', Twist, self.twist_callback)

    def twist_callback(self, msg):
        self.v_ = msg.linear.x
        self.w_ = msg.angular.z

    def wrap_to_Pi(self, theta):
        result = np.fmod((theta + np.pi), (2 * np.pi))
        if result < 0:
            result += 2 * np.pi
        return result - np.pi

    def pose_stamped(self, x, y, theta_yaw):
        pose_robot = PoseStamped()
        pose_robot.header.stamp = rospy.Time.now()
        pose_robot.header.frame_id = "odom"
        pose_robot.pose.position.x = x
        pose_robot.pose.position.y = y
        quaternion = Quaternion(*quaternion_from_euler(0, 0, theta_yaw))
        pose_robot.pose.orientation = quaternion
        return pose_robot

    def vel_xyz(self, theta):
        # No linealizado
        x_dot = self.v_ * np.cos(theta)
        y_dot = self.v_ * np.sin(theta)
        theta_dot = self.w_
        return x_dot, y_dot, theta_dot

    def simulate(self):
        theta = 0.0
        x = 0.0
        y = 0.0

        while not rospy.is_shutdown():
            current_time = rospy.Time.now().to_sec()  # Get current time
            if self.first:
                self.previous_time = current_time
                self.first = False
            else:
                dt = current_time - self.previous_time  # get dt
                self.previous_time = current_time

                # PoseStamped
                self.x_dot, self.y_dot, self.theta_dot = self.vel_xyz(theta)
                x += self.x_dot * dt
                y += self.y_dot * dt
                theta += self.theta_dot * dt
                theta = self.wrap_to_Pi(theta)

                pose_puzzlebot = self.pose_stamped(x, y, theta)
                self.pub_pose.publish(pose_puzzlebot)
                # end
                self.loop_rate.sleep()

if __name__ == '__main__':
    try:
        aruco_detector = ArucoDetector()
        simulation = Simulation()
        simulation.simulate()
    except rospy.ROSInterruptException:
        pass
    finally:
        cv2.destroyAllWindows()
