#!/usr/bin/env python
import rospy 
import numpy as np
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from geometry_msgs.msg import TransformStamped, Quaternion
from tf import TransformBroadcaster
from tf.transformations import quaternion_from_euler


class transform:
    def __init__(self):
          #Initialize
          rospy.init_node("puzzlebot_transform_2")
          self.loop_rate = rospy.Rate(rospy.get_param("~node_rate",100))
          #Parameters
          self.first=True
          self.x_odom=0.0
          self.y_odom=0.0
          self.x_pose=0.0
          self.y_pose=0.0
          #Messages 
          self.snt_tnf=TransformBroadcaster()
          self.quaternion=Quaternion(*quaternion_from_euler(0,0,0))
          #Publishers and Suscribers
          rospy.Subscriber('/puzzlebot_1/base_pose_ground_truth', Odometry, self.odom_callback)         
          
 

    def odom_callback(self, odom):
        self.x_odom = odom.pose.pose.position.x
        self.y_odom = odom.pose.pose.position.y
        self.quaternion = odom.pose.pose.orientation    
     
      
     
    def transform(self):
        tnf=TransformStamped()
        tnf.header.stamp=rospy.Time.now()
        tnf.header.frame_id= "odom"
        tnf.child_frame_id="/puzzlebot_1/base_link"
        tnf.transform.translation.x = self.x_odom
        tnf.transform.translation.y = self.y_odom
        tnf.transform.translation.z = 0.0
        #rotation
        tnf.transform.rotation = self.quaternion
        self.snt_tnf.sendTransformMessage(tnf)
    
    def run(self):
            
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()  # Get current time

            if self.first:
                self.previous_time = current_time
                self.first = False
            else:
                dt = (current_time - self.previous_time).to_sec()  # get dt
                self.previous_time = current_time
                #wheel joints
                # Publish transform
                self.transform()
                print(self.x_odom)

if __name__=='__main__':
    trans=transform()
    try:
         trans.run()  
    except rospy.ROSInterruptException:
        pass 
    
