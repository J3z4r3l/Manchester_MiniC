#! /usr/bin/env python
import rospy
import tf
import tf2_ros
from math import sin, cos, pi
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3, PoseStamped, Pose2D, TransformStamped
import numpy as np
import tf_conversions
from tf.transformations import quaternion_from_euler
from std_msgs.msg import Float32
from camera_puzzlebot.msg import imagen_aruco  # type: ignore


##This is the new real pose????
class OdometryPublisher:
    def __init__(self):
        rospy.init_node('odometry_sim')
        self.rate = rospy.Rate(100) 
        
        # ========= PUBLICADORES A TOPICOS =================
        self.odom_pub = rospy.Publisher("/odom", Odometry, queue_size=50)
        self.pJS = rospy.Publisher("/joint_states", JointState, queue_size=10)
        self.pPose = rospy.Publisher('/pose', PoseStamped, queue_size=10)
        
        rospy.Subscriber("/wr_1",Float32,self.wr_real_callback)
        rospy.Subscriber("/wl_1",Float32,self.wl_real_callback)
        rospy.Subscriber('/data_aruco', imagen_aruco, self.aruco_info_callback)
        
        self.ta = tf2_ros.TransformBroadcaster() 
        self.M = {0: [2.5, 2.5], 1: [2.8, -2.0], 2: [0.5, -3.5], 3: [-2.5, -0.5]}
        self.odom_msg = Odometry()
        
        self.aruco_id = -1
        self.magnitud = 0
        self.angulo = 0
        #Wheels
        self.wr_speed=0.0
        self.wl_speed=0.0
        self.vel=0.0
        self.w=0.0
        self.theta = 0.0
        self.x=0.0
        self.y=0.0
        self.rotation=0.0
        self.mu = np.array([0.0,0.0,0.0])
        self.radius=0.05
        self.wheelbase=0.19
        self.first= True 
        self.kr=1.3
        self.kl=1.3
        ##Try to get 0 in covariance 
        rospy.Subscriber('/puzzlebot_1/base_controller/cmd_vel', Twist, self.callback_twist)
        self.vel_x_t=0.0
        self.vel_z_t=0.0
        #Covariance
        self.H_matrix=np.zeros((3,3),dtype=float)
        self.covariance_matrix=np.zeros((3,3),dtype=float)
        self.covariance_matrix_2=np.zeros((3,3),dtype=float)
        self.Qk_matrix=np.zeros((3,3),dtype=float)
        self.cov_delta_q = np.zeros((2,2), dtype=float)
        self.angulo_img=0.0
        self.distance_img=0.0
        self.id_img=0
        self.bool_img=False

    def callback_twist(self,msg):
        self.vel_x_t=msg.linear.x
        self.vel_z_t=msg.angular.z
    
    ##Wheels callback 
    def wr_real_callback(self, v_r):
        self.wr_speed = v_r.data
    def wl_real_callback(self, v_l):
        self.wl_speed = v_l.data

    #Adjust angle    
    def wrap_to_Pi(self, theta):
        return (theta + np.pi) % (2 * np.pi) - np.pi

    
    def aruco_info_callback(self,msg):
        self.angulo_img=msg.angle
        self.distance_img=msg.distance
        self.id_img=msg.id_img
        self.bool_img=msg.aruco
        if self.bool_img:
        #si bool es true=recibimos imagenes, pasamos al primer if
        #si no recibe id id=-1 a lo mejor no es necesario 
        #si se recibe valores sig
            if self.id_img in self.M.keys():
                print("SI EXISTE EL ARUCO\n\n")

                self.magnitud = self.distance_img
                self.angulo = self.angulo_img
                self.aruco_id=self.id_img
                print(self.magnitud,self.angulo,self.wrap_to_Pi(self.angulo))

            else:
                print("NO EXISTE EL ARUCO\n\n")
                self.magnitud = 0
                self.angulo = 0
                self.aruco_id = -1 #conectada al primer  if 
        else:
            self.magnitud = 0
            self.angulo = 0
            self.aruco_id = -1

    #Position vector 
    def get_positon(self,wr,wl,dt):
        self.vel=self.radius*(wr+wl)/2
        self.w=self.radius*(wr-wl)/self.wheelbase
        self.mu[2] += self.w*dt
        self.mu[0] += self.vel*np.cos(self.mu[2])*dt
        self.mu[1] += self.vel*np.sin(self.mu[2])*dt
        #self.mu = np.array([self.x, self.y, self.theta])
        return  self.mu
    
    #Covariance step 1-5
    def get_covariance(self, dt):
        gra_wk = 0.5 * self.radius * dt * np.array([
            [np.cos(self.theta), np.cos(self.theta)],
            [np.sin(self.theta), np.sin(self.theta)],
            [2.0 / self.wheelbase, -2.0 / self.wheelbase]
        ])

        self.cov_delta_q = np.array([
            [self.kr * abs(self.wr_speed), 0.0],
            [0.0, self.kl * abs(self.wl_speed)]
        ])

        self.Qk_matrix = np.matmul(gra_wk, np.matmul(self.cov_delta_q, gra_wk.T))

        self.H_matrix = np.array([
            [1.0, 0.0, -dt * self.vel * np.sin(self.theta)],
            [0.0, 1.0, dt * self.vel * np.cos(self.theta)],
            [0.0, 0.0, 1.0]
        ])

        self.covariance_matrix = np.matmul(self.H_matrix, np.matmul(self.covariance_matrix, self.H_matrix.T)) + self.Qk_matrix

        print("gra_wk:\n", gra_wk)
        print("cov_delta_q:\n", self.cov_delta_q)
        print("Qk_matrix:\n", self.Qk_matrix)
        print("H_matrix:\n", self.H_matrix)
        print("covariance_matrix:\n", self.covariance_matrix)

        return self.covariance_matrix


    
    ##Step 5-12 
    def EKF(self, Muk_ant, sigmak_ant, Zik, Rk):
        Zik = np.array(Zik, dtype=np.float64)
        Muk = np.array(Muk_ant, dtype=np.float64)
        sigmak = np.array(sigmak_ant, dtype=np.float64)
        Rk = np.array(Rk, dtype=np.float64)

        if self.aruco_id in self.M.keys():
            delta_x = self.M[self.aruco_id][0] - Muk[0]
            delta_y = self.M[self.aruco_id][1] - Muk[1]
            p = (delta_x ** 2 + delta_y ** 2)

            Zik_e = np.array([
                np.sqrt(p),
                np.arctan2(delta_y, delta_x) - Muk[2]
            ], dtype=np.float64)

            Gk = np.array([
                [-delta_x / np.sqrt(p), -delta_y / np.sqrt(p), 0],
                [delta_y / p, -delta_x / p, -1]
            ], dtype=np.float64)

            Zk = np.matmul(Gk, np.matmul(sigmak, Gk.T)) + Rk

            Kk = np.matmul(sigmak, np.matmul(Gk.T, np.linalg.pinv(Zk)))

            Muk += np.matmul(Kk, (Zik - Zik_e))

            I = np.eye(3, dtype=np.float64)

            sigmak = np.matmul((I - np.matmul(Kk, Gk)), sigmak)

        return Muk, sigmak


    def send_odometry(self, current_time, mu, covarianza):
        self.odom_msg.header.stamp = current_time
        self.odom_msg.header.frame_id = "odom"
        self.odom_msg.child_frame_id = "base_link"
        self.odom_msg.pose.pose.position.x = mu[0]
        self.odom_msg.pose.pose.position.y = mu[1]
        self.odom_msg.pose.pose.orientation = Quaternion(*quaternion_from_euler(0, 0, mu[2]))

        co = np.zeros((6, 6))
        co[0:2, 0:2] = covarianza[0:2, 0:2]
        co[5, 0:2] = covarianza[2, 0:2]
        co[0:2, 5] = covarianza[0:2, 2]
        co[5, 5] = covarianza[2, 2]
        self.odom_msg.pose.covariance = co.reshape(36).tolist()

        self.odom_msg.twist.twist.linear.x = self.vel
        self.odom_msg.twist.twist.angular.z = self.w

        return self.odom_msg


    def run(self):
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()
            if self.first:
                self.previous_time = current_time
                if self.vel_x_t != 0 or self.vel_z_t != 0:
                    self.first = False
                odom_msg = self.send_odometry(current_time, self.mu, self.covariance_matrix)
                self.odom_pub.publish(odom_msg)
            else:
                dt = (current_time - self.previous_time).to_sec()
                self.previous_time = current_time
    
                self.covariance_matrix_2 = self.get_covariance(dt)
                self.mu = self.get_positon(self.wr_speed, self.wl_speed, dt)
                self.mu[2] = self.wrap_to_Pi(self.mu[2])
                self.theta = self.mu[2]
    
                Zik = [self.magnitud, self.angulo]
                error = 0.2
                Rk = np.eye(2) * error
                self.mu, self.covariance_matrix_2 = self.EKF(self.mu, self.covariance_matrix_2, Zik, Rk)
                self.mu[2] = self.wrap_to_Pi(self.mu[2])
    
                odom_msg = self.send_odometry(current_time, self.mu, self.covariance_matrix_2)
                self.odom_pub.publish(odom_msg)
                self.rate.sleep()
       

if __name__ == '__main__':
    try:
        odometry_publisher = OdometryPublisher()
        odometry_publisher.run()
    except rospy.ROSInterruptException:
        pass
