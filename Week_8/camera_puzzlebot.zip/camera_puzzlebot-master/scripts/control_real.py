#!/usr/bin/env python
import rospy
import numpy as np
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from std_msgs.msg import Int32
class ControlPID:
    def __init__(self, dt, kp=1, ki=0, kd=0):
        self.dt = dt
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0
        self.error_actual = 0
        self.pred = 0
        self.x_list = 0.0
        self.y_list = 0.0
        self.error_ang = 0.0

    def points_callback(self, x, y):
        self.x_list = x
        self.y_list = y

    def get_pid(self, current, goal):
        error_p = goal - current
        self.integral += self.ki * error_p * self.dt
        ed = (error_p - self.error_actual) / self.dt
        self.error_actual = error_p
        self.pred = current + (error_p * self.kp) + self.integral + (ed * self.kd)
        return self.pred

    def get_pid_d(self, goal):
        error_p = goal
        self.integral += self.ki * error_p * self.dt
        ed = (error_p - self.error_actual) / self.dt
        self.error_actual = error_p
        self.pred = (error_p * self.kp) + self.integral + (ed * self.kd)
        return self.pred

    def e_ang(self, z_pose, x, y):
        self.error_ang = np.arctan2(self.y_list - y, self.x_list - x)
        a = self.error_ang - z_pose
        return a

    def e_dis(self, x, y):
        error_dist = np.sqrt((self.x_list - x) ** 2 + (self.y_list - y) ** 2)
        return error_dist

class Bugs:
    def __init__(self):
        rospy.init_node('control_r')
        rospy.Subscriber('/puzzlebot_1/base_pose_ground_truth', Odometry, self.odom_callback)
        self.vel_pub = rospy.Publisher('/puzzlebot_1/base_controller/cmd_vel', Twist, queue_size=10)
        self.pub_index=rospy.Publisher('/index', Int32, queue_size=10)
        self.vel = Twist()
        self.x_odom = 0.0
        self.y_odom = 0.0
        self.quaternion = None
        self.pos_z = 0.0
        self.rate = rospy.Rate(100)
        self.first = True
        self.goal_x = [ 2,  3,  1, -2]
        self.goal_y = [ 2, -1, -3.1, -1.2]
        self.turnPID = ControlPID(0.09, kp=0.4, kd=0.003)
        self.fowaPID = ControlPID(0.09, kp=0.2, kd=0.005)

    def odom_callback(self, odom):
        self.x_odom = odom.pose.pose.position.x
        self.y_odom = odom.pose.pose.position.y
        self.quaternion = odom.pose.pose.orientation
        (_, _, self.pos_z) = euler_from_quaternion([self.quaternion.x, self.quaternion.y, self.quaternion.z, self.quaternion.w])

    def run(self):
        error_a = 0.0
        error_d = 0.0
        index = 0
        while not rospy.is_shutdown():
            if self.first:
                self.current_time = rospy.get_time()
                self.previous_time = rospy.get_time()
                self.first = False

            else:
                self.current_time = rospy.get_time()
                self.previous_time = self.current_time
                dt = 0.09
                ##Instance class
                if index < len(self.goal_x):
                    self.turnPID.points_callback(self.goal_x[index], self.goal_y[index])
                    self.fowaPID.points_callback(self.goal_x[index], self.goal_y[index])

                    error_a = self.turnPID.e_ang(self.pos_z, self.x_odom, self.y_odom)
                    error_d = self.fowaPID.e_dis(self.x_odom, self.y_odom)
                    print("try PID")
                    print(error_a,error_d)

                    if abs(error_a) > 0.3:
                        print("Ang PID")
                        self.vel.angular.z = self.turnPID.get_pid(self.pos_z, error_a)
                        self.vel.linear.x = 0.0
                        
                    elif abs(error_a) <= 0.3 and abs(error_d) >= 0.1:
                        print("Dist PID")
                        self.vel.angular.z = 0.0
                        self.vel.linear.x = self.fowaPID.get_pid_d(error_d)
                        
                    elif abs(error_a) <= 0.3 and abs(error_d) <= 0.1:
                        self.vel.angular.z = 0.0
                        self.vel.linear.x = 0.0
                        index += 1
                    
                else:
                    self.vel.angular.z = 0.0
                    self.vel.linear.x = 0.0

                self.pub_index.publish(index)
                self.vel_pub.publish(self.vel)        
                self.rate.sleep()

if __name__ == "__main__":
    try:
        node = Bugs()
        node.run()
    except rospy.ROSInterruptException:
        pass

