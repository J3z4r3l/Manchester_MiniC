#!/usr/bin/env python
import rospy
import cv2
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image
from geometry_msgs.msg import TransformStamped, Quaternion
import tf2_ros
import numpy as np
from tf.transformations import quaternion_from_euler
from camera_puzzlebot.msg import imagen_aruco   # type: ignore
class ArucoDetector:
    def __init__(self):
        self.bridge = CvBridge()
        self.parametros = cv2.aruco.DetectorParameters_create()
        self.diccionario = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
        
        self.camera_matrix = np.array([[1000.0, 0.0, 630.0],
                                       [0.0, 1000.0, 630.0],
                                       [0.0, 0.0, 1.0]], dtype=np.float32)
        self.dist_coeffs = np.array([0.1, -0.25, 0.0, 0.0, 0.0], dtype=np.float32)

        self.marker_size = 0.13
        self.data_image=imagen_aruco()
        rospy.init_node('aruco_detector', anonymous=True)
        self.image_sub = rospy.Subscriber('puzzlebot_1/camera/image_raw', Image, self.image_callback)
        self.image_pub = rospy.Publisher('/fiducial_images', Image, queue_size=10)
        self.data_image_pub = rospy.Publisher('/data_aruco', imagen_aruco, queue_size=10)
       
        self.tf_broadcaster = tf2_ros.TransformBroadcaster()  # Inicializar el broadcaster de transformaciones

        rospy.spin()

    def image_callback(self, data):
        try:
            frame = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {0}".format(e))
            return
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        esquinas, ids, _ = cv2.aruco.detectMarkers(gray, self.diccionario, parameters=self.parametros)
        aruco_bool=False
        if ids is not None:
            frame = cv2.aruco.drawDetectedMarkers(frame, esquinas)
            rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(esquinas, self.marker_size, self.camera_matrix, self.dist_coeffs)
            
            for i in range(len(ids)):
                aruco_id = ids[i][0]
                aruco_bool=True
                rvec = rvecs[i][0]
                tvec = tvecs[i][0]
    
                x = tvecs[i][0][0]
                y = tvec[1]
                z = tvec[2]

                #print("ArUco ID:", aruco_id)
                #print("Coordenadas (x, y, z):", x, y, z)
                #print("tevec", tvec)
                distance = np.linalg.norm(tvec) + 0.25
                angle = np.arctan2(tvec[0], tvec[2])
                angle_degrees = np.degrees(angle)
                #print(tvec[0],aruco_id)
                print("distancia", distance)
                print("angulo", angle)
                self.data_image.id_img=aruco_id
                self.data_image.distance=distance
                
                if distance>3:
                    aruco_bool=False

                self.data_image.angle=abs(angle)
                self.data_image.aruco=aruco_bool
                #mandar un bool true 
                self.data_image_pub.publish(self.data_image)
                cv2.aruco.drawAxis(frame, self.camera_matrix, self.dist_coeffs, rvec, tvec, 0.1)

                self.send_transform(tvec, rvec, aruco_id)
        else:
            rospy.loginfo("No se detectaron Arucos")
            ##mandar bool false, 1 o 0
            aruco_bool=False
            self.data_image.aruco=aruco_bool
            self.data_image_pub.publish(self.data_image)
                
        
        try:
            image_msg = self.bridge.cv2_to_imgmsg(frame, "bgr8")
            self.image_pub.publish(image_msg)
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: {0}".format(e))

    def send_transform(self, tvec, rvec, marker_id):
        t = TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = '/puzzlebot_1/base_link'
        t.child_frame_id = 'aruco_marker_{}'.format(marker_id)

        t.transform.translation.x = tvec[2]+0.3
        t.transform.translation.y = tvec[0]
        t.transform.translation.z = 0
        
        q = quaternion_from_euler(rvec[0], rvec[1], rvec[2])
        t.transform.rotation = Quaternion(*q)
        #print(q[2])
        self.tf_broadcaster.sendTransform(t)

if __name__ == '__main__':
    try:
        ArucoDetector()
    except rospy.ROSInterruptException:
        pass
    finally:
        cv2.destroyAllWindows()
